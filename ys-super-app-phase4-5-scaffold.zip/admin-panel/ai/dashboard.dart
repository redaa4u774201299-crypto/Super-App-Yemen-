import 'package:flutter/material.dart';

/// لوحة تحكم الذكاء الاصطناعي — لوحة التحكم
/// الوظيفة: عرض ملخص عام لاستخدام كل خدمات الذكاء الاصطناعي
/// TODO: ربط هذه الصفحة بواجهة API الإدارية الفعلية.
class AiDashboardPage extends StatelessWidget {
  const AiDashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة تحكم الذكاء الاصطناعي')),
      body: const Center(
        child: Text('لوحة إدارية قيد التطوير — بيانات تجريبية لاحقًا.'),
      ),
    );
  }
}
