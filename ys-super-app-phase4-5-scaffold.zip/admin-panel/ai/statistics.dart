import 'package:flutter/material.dart';

/// إحصائيات الذكاء الاصطناعي — لوحة التحكم
/// الوظيفة: عرض إحصائيات الاستخدام (رسائل، بحث، ترجمة، اقتراحات)
/// TODO: ربط هذه الصفحة بواجهة API الإدارية الفعلية.
class AiStatisticsPage extends StatelessWidget {
  const AiStatisticsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إحصائيات الذكاء الاصطناعي')),
      body: const Center(
        child: Text('لوحة إدارية قيد التطوير — بيانات تجريبية لاحقًا.'),
      ),
    );
  }
}
