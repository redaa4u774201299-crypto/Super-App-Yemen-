import 'package:flutter/material.dart';

/// مستخدمو الذكاء الاصطناعي — لوحة التحكم
/// الوظيفة: عرض المستخدمين الأكثر استخدامًا لخدمات الذكاء الاصطناعي
/// TODO: ربط هذه الصفحة بواجهة API الإدارية الفعلية.
class AiUsersPage extends StatelessWidget {
  const AiUsersPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مستخدمو الذكاء الاصطناعي')),
      body: const Center(
        child: Text('لوحة إدارية قيد التطوير — بيانات تجريبية لاحقًا.'),
      ),
    );
  }
}
