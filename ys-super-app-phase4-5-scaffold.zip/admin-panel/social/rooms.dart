import 'package:flutter/material.dart';

/// إدارة الغرف الصوتية — لوحة التحكم
/// الوظيفة: مراقبة وإدارة الغرف الصوتية النشطة
/// TODO: ربط هذه الصفحة بواجهة API الإدارية الفعلية.
class SocialRoomsPage extends StatelessWidget {
  const SocialRoomsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إدارة الغرف الصوتية')),
      body: const Center(
        child: Text('لوحة إدارية قيد التطوير — بيانات تجريبية لاحقًا.'),
      ),
    );
  }
}
