import 'package:flutter/material.dart';

/// إدارة المجموعات — لوحة التحكم
/// الوظيفة: مراقبة وإدارة المجموعات
/// TODO: ربط هذه الصفحة بواجهة API الإدارية الفعلية.
class SocialGroupsPage extends StatelessWidget {
  const SocialGroupsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إدارة المجموعات')),
      body: const Center(
        child: Text('لوحة إدارية قيد التطوير — بيانات تجريبية لاحقًا.'),
      ),
    );
  }
}
