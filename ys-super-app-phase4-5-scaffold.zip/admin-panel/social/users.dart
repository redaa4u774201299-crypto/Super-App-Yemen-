import 'package:flutter/material.dart';

/// إدارة المستخدمين — لوحة التحكم
/// الوظيفة: إدارة حسابات المستخدمين ضمن الوحدة الاجتماعية
/// TODO: ربط هذه الصفحة بواجهة API الإدارية الفعلية.
class SocialUsersPage extends StatelessWidget {
  const SocialUsersPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إدارة المستخدمين')),
      body: const Center(
        child: Text('لوحة إدارية قيد التطوير — بيانات تجريبية لاحقًا.'),
      ),
    );
  }
}
