import 'package:flutter/material.dart';

/// إدارة البث المباشر — لوحة التحكم
/// الوظيفة: مراقبة البثوث النشطة وإيقافها عند الحاجة
/// TODO: ربط هذه الصفحة بواجهة API الإدارية الفعلية.
class SocialLivePage extends StatelessWidget {
  const SocialLivePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إدارة البث المباشر')),
      body: const Center(
        child: Text('لوحة إدارية قيد التطوير — بيانات تجريبية لاحقًا.'),
      ),
    );
  }
}
