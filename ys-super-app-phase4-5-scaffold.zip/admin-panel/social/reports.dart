import 'package:flutter/material.dart';

/// البلاغات — لوحة التحكم
/// الوظيفة: مراجعة بلاغات المستخدمين واتخاذ الإجراء المناسب
/// TODO: ربط هذه الصفحة بواجهة API الإدارية الفعلية.
class SocialReportsPage extends StatelessWidget {
  const SocialReportsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('البلاغات')),
      body: const Center(
        child: Text('لوحة إدارية قيد التطوير — بيانات تجريبية لاحقًا.'),
      ),
    );
  }
}
