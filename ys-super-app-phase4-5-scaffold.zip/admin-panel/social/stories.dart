import 'package:flutter/material.dart';

/// إدارة الحالات — لوحة التحكم
/// الوظيفة: مراجعة الحالات المنشورة وحذف المخالف منها
/// TODO: ربط هذه الصفحة بواجهة API الإدارية الفعلية.
class SocialStoriesPage extends StatelessWidget {
  const SocialStoriesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إدارة الحالات')),
      body: const Center(
        child: Text('لوحة إدارية قيد التطوير — بيانات تجريبية لاحقًا.'),
      ),
    );
  }
}
