import 'package:flutter/material.dart';

/// الغرف الصوتية
/// الوظيفة: عرض قائمة الغرف الصوتية المتاحة
/// TODO: ربط الشاشة بـ RoomService لعرض الغرف النشطة فعليًا
class RoomsScreen extends StatefulWidget {
  const RoomsScreen({super.key});

  @override
  State<RoomsScreen> createState() => _RoomsScreenState();
}

class _RoomsScreenState extends State<RoomsScreen> {
  bool _isLoading = false;
  String? _errorMessage;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الغرف الصوتية')),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_errorMessage!, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => setState(() => _errorMessage = null),
              child: const Text('إعادة المحاولة'),
            ),
          ],
        ),
      );
    }
    // TODO: ربط الشاشة بـ RoomService لعرض الغرف النشطة فعليًا
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'هذه الشاشة قيد التطوير وسيتم ربطها بالخدمة الفعلية في مرحلة لاحقة.',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
