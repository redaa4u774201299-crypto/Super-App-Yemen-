/// نموذج بيانات المتحدث داخل الغرفة الصوتية

class SpeakerModel {
  final String userId;
  final String roomId;
  final bool isMuted;
  final bool isModerator;
  final bool handRaised;

  const SpeakerModel({
    required this.userId,
    required this.roomId,
    required this.isMuted,
    required this.isModerator,
    required this.handRaised,
  });

  factory SpeakerModel.fromJson(Map<String, dynamic> json) {
    return SpeakerModel(
        userId: json['userId'],
        roomId: json['roomId'],
        isMuted: json['isMuted'],
        isModerator: json['isModerator'],
        handRaised: json['handRaised'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
        'userId': userId,
        'roomId': roomId,
        'isMuted': isMuted,
        'isModerator': isModerator,
        'handRaised': handRaised,
    };
  }
}
