/// نموذج بيانات الغرفة الصوتية

class RoomModel {
  final String id;
  final String title;
  final String hostId;
  final bool isLive;
  final int listenersCount;
  final String createdAt;

  const RoomModel({
    required this.id,
    required this.title,
    required this.hostId,
    required this.isLive,
    required this.listenersCount,
    required this.createdAt,
  });

  factory RoomModel.fromJson(Map<String, dynamic> json) {
    return RoomModel(
        id: json['id'],
        title: json['title'],
        hostId: json['hostId'],
        isLive: json['isLive'],
        listenersCount: json['listenersCount'],
        createdAt: json['createdAt'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
        'id': id,
        'title': title,
        'hostId': hostId,
        'isLive': isLive,
        'listenersCount': listenersCount,
        'createdAt': createdAt,
    };
  }
}
