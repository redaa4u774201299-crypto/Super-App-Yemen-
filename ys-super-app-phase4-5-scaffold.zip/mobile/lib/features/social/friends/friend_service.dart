/// خدمة الأصدقاء
/// الوظيفة: إرسال طلب صداقة، قبول الطلب، رفض الطلب، حذف الصديق، حظر المستخدم
class FriendService {
  FriendService._internal();
  static final FriendService instance = FriendService._internal();

  factory FriendService() => instance;

  /// إرسال طلب صداقة
  Future<void> sendFriendRequest(String userId) async {
    // TODO: استبدال هذا المنطق التجريبي باتصال فعلي بواجهة API.
    throw UnimplementedError('سيتم تنفيذ sendFriendRequest عند اكتمال الربط بالخادم');
  }

  /// قبول طلب صداقة
  Future<void> acceptFriendRequest(String requestId) async {
    // TODO: استبدال هذا المنطق التجريبي باتصال فعلي بواجهة API.
    throw UnimplementedError('سيتم تنفيذ acceptFriendRequest عند اكتمال الربط بالخادم');
  }

  /// رفض طلب صداقة
  Future<void> rejectFriendRequest(String requestId) async {
    // TODO: استبدال هذا المنطق التجريبي باتصال فعلي بواجهة API.
    throw UnimplementedError('سيتم تنفيذ rejectFriendRequest عند اكتمال الربط بالخادم');
  }

  /// حذف صديق
  Future<void> removeFriend(String userId) async {
    // TODO: استبدال هذا المنطق التجريبي باتصال فعلي بواجهة API.
    throw UnimplementedError('سيتم تنفيذ removeFriend عند اكتمال الربط بالخادم');
  }

  /// حظر مستخدم
  Future<void> blockUser(String userId) async {
    // TODO: استبدال هذا المنطق التجريبي باتصال فعلي بواجهة API.
    throw UnimplementedError('سيتم تنفيذ blockUser عند اكتمال الربط بالخادم');
  }

}
