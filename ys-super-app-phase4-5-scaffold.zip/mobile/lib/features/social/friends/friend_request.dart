/// نموذج بيانات طلب الصداقة

class FriendRequestModel {
  final String id;
  final String fromUserId;
  final String toUserId;
  final String status;
  final String createdAt;

  const FriendRequestModel({
    required this.id,
    required this.fromUserId,
    required this.toUserId,
    required this.status,
    required this.createdAt,
  });

  factory FriendRequestModel.fromJson(Map<String, dynamic> json) {
    return FriendRequestModel(
        id: json['id'],
        fromUserId: json['fromUserId'],
        toUserId: json['toUserId'],
        status: json['status'],
        createdAt: json['createdAt'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
        'id': id,
        'fromUserId': fromUserId,
        'toUserId': toUserId,
        'status': status,
        'createdAt': createdAt,
    };
  }
}
