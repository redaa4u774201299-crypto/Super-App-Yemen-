import 'package:flutter/material.dart';

/// الملف الشخصي للصديق
/// الوظيفة: عرض تفاصيل صديق معين
/// TODO: ربط الشاشة ببيانات المستخدم الفعلية عبر FriendService
class FriendProfileScreen extends StatefulWidget {
  const FriendProfileScreen({super.key});

  @override
  State<FriendProfileScreen> createState() => _FriendProfileScreenState();
}

class _FriendProfileScreenState extends State<FriendProfileScreen> {
  bool _isLoading = false;
  String? _errorMessage;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الملف الشخصي للصديق')),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_errorMessage!, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => setState(() => _errorMessage = null),
              child: const Text('إعادة المحاولة'),
            ),
          ],
        ),
      );
    }
    // TODO: ربط الشاشة ببيانات المستخدم الفعلية عبر FriendService
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'هذه الشاشة قيد التطوير وسيتم ربطها بالخدمة الفعلية في مرحلة لاحقة.',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
