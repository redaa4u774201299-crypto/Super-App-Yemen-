/// نموذج بيانات البث المباشر

class LiveModel {
  final String id;
  final String hostId;
  final String title;
  final int viewersCount;
  final String startedAt;
  final bool isActive;

  const LiveModel({
    required this.id,
    required this.hostId,
    required this.title,
    required this.viewersCount,
    required this.startedAt,
    required this.isActive,
  });

  factory LiveModel.fromJson(Map<String, dynamic> json) {
    return LiveModel(
        id: json['id'],
        hostId: json['hostId'],
        title: json['title'],
        viewersCount: json['viewersCount'],
        startedAt: json['startedAt'],
        isActive: json['isActive'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
        'id': id,
        'hostId': hostId,
        'title': title,
        'viewersCount': viewersCount,
        'startedAt': startedAt,
        'isActive': isActive,
    };
  }
}
