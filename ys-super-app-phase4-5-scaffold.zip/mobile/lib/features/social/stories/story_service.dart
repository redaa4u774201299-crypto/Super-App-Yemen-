/// خدمة الحالات
/// الوظيفة: رفع صورة، رفع فيديو، مدة العرض 24 ساعة، عدد المشاهدات، التفاعل
class StoryService {
  StoryService._internal();
  static final StoryService instance = StoryService._internal();

  factory StoryService() => instance;

  /// رفع حالة صورة
  Future<StoryModel> uploadImageStory(String imagePath) async {
    // TODO: استبدال هذا المنطق التجريبي باتصال فعلي بواجهة API.
    throw UnimplementedError('سيتم تنفيذ uploadImageStory عند اكتمال الربط بالخادم');
  }

  /// رفع حالة فيديو
  Future<StoryModel> uploadVideoStory(String videoPath) async {
    // TODO: استبدال هذا المنطق التجريبي باتصال فعلي بواجهة API.
    throw UnimplementedError('سيتم تنفيذ uploadVideoStory عند اكتمال الربط بالخادم');
  }

  /// تسجيل مشاهدة على الحالة
  Future<void> recordView(String storyId) async {
    // TODO: استبدال هذا المنطق التجريبي باتصال فعلي بواجهة API.
    throw UnimplementedError('سيتم تنفيذ recordView عند اكتمال الربط بالخادم');
  }

  /// إضافة تفاعل على الحالة
  Future<void> reactToStory(String storyId, String reaction) async {
    // TODO: استبدال هذا المنطق التجريبي باتصال فعلي بواجهة API.
    throw UnimplementedError('سيتم تنفيذ reactToStory عند اكتمال الربط بالخادم');
  }

}
