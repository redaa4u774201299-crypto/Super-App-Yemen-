/// نموذج بيانات الحالة — صالحة لمدة 24 ساعة من وقت النشر

class StoryModel {
  final String id;
  final String userId;
  final String mediaUrl;
  final String mediaType;
  final String createdAt;
  final String expiresAt;
  final int viewsCount;

  const StoryModel({
    required this.id,
    required this.userId,
    required this.mediaUrl,
    required this.mediaType,
    required this.createdAt,
    required this.expiresAt,
    required this.viewsCount,
  });

  factory StoryModel.fromJson(Map<String, dynamic> json) {
    return StoryModel(
        id: json['id'],
        userId: json['userId'],
        mediaUrl: json['mediaUrl'],
        mediaType: json['mediaType'],
        createdAt: json['createdAt'],
        expiresAt: json['expiresAt'],
        viewsCount: json['viewsCount'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
        'id': id,
        'userId': userId,
        'mediaUrl': mediaUrl,
        'mediaType': mediaType,
        'createdAt': createdAt,
        'expiresAt': expiresAt,
        'viewsCount': viewsCount,
    };
  }
}
