import 'package:flutter/material.dart';

/// الإشعارات الاجتماعية
/// الوظيفة: عرض إشعارات: رسالة جديدة، طلب صداقة، تعليق، إعجاب، دعوة غرفة، بدء بث
/// TODO: ربط الشاشة بـ NotificationService لعرض الإشعارات الفعلية
class SocialNotificationsScreen extends StatefulWidget {
  const SocialNotificationsScreen({super.key});

  @override
  State<SocialNotificationsScreen> createState() => _SocialNotificationsScreenState();
}

class _SocialNotificationsScreenState extends State<SocialNotificationsScreen> {
  bool _isLoading = false;
  String? _errorMessage;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإشعارات الاجتماعية')),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_errorMessage!, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => setState(() => _errorMessage = null),
              child: const Text('إعادة المحاولة'),
            ),
          ],
        ),
      );
    }
    // TODO: ربط الشاشة بـ NotificationService لعرض الإشعارات الفعلية
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'هذه الشاشة قيد التطوير وسيتم ربطها بالخدمة الفعلية في مرحلة لاحقة.',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
