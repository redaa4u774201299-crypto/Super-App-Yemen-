import 'package:flutter/material.dart';

/// المجموعات
/// الوظيفة: عرض قائمة المجموعات التي ينتمي إليها المستخدم
/// TODO: ربط الشاشة بـ GroupService لعرض المجموعات الفعلية
class GroupsScreen extends StatefulWidget {
  const GroupsScreen({super.key});

  @override
  State<GroupsScreen> createState() => _GroupsScreenState();
}

class _GroupsScreenState extends State<GroupsScreen> {
  bool _isLoading = false;
  String? _errorMessage;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المجموعات')),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_errorMessage!, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => setState(() => _errorMessage = null),
              child: const Text('إعادة المحاولة'),
            ),
          ],
        ),
      );
    }
    // TODO: ربط الشاشة بـ GroupService لعرض المجموعات الفعلية
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'هذه الشاشة قيد التطوير وسيتم ربطها بالخدمة الفعلية في مرحلة لاحقة.',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
