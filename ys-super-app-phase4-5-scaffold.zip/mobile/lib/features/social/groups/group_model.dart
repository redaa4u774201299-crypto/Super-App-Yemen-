/// نموذج بيانات المجموعة

class GroupModel {
  final String id;
  final String name;
  final String ownerId;
  final int membersCount;
  final String createdAt;

  const GroupModel({
    required this.id,
    required this.name,
    required this.ownerId,
    required this.membersCount,
    required this.createdAt,
  });

  factory GroupModel.fromJson(Map<String, dynamic> json) {
    return GroupModel(
        id: json['id'],
        name: json['name'],
        ownerId: json['ownerId'],
        membersCount: json['membersCount'],
        createdAt: json['createdAt'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
        'id': id,
        'name': name,
        'ownerId': ownerId,
        'membersCount': membersCount,
        'createdAt': createdAt,
    };
  }
}
