/// نموذج بيانات الرسالة الواحدة داخل المحادثة

class MessageModel {
  final String id;
  final String conversationId;
  final String senderId;
  final String text;
  final String sentAt;
  final bool isRead;

  const MessageModel({
    required this.id,
    required this.conversationId,
    required this.senderId,
    required this.text,
    required this.sentAt,
    required this.isRead,
  });

  factory MessageModel.fromJson(Map<String, dynamic> json) {
    return MessageModel(
        id: json['id'],
        conversationId: json['conversationId'],
        senderId: json['senderId'],
        text: json['text'],
        sentAt: json['sentAt'],
        isRead: json['isRead'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
        'id': id,
        'conversationId': conversationId,
        'senderId': senderId,
        'text': text,
        'sentAt': sentAt,
        'isRead': isRead,
    };
  }
}
