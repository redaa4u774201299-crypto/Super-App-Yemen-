/// نموذج بيانات عنصر في قائمة المحادثات

class ConversationModel {
  final String id;
  final String participantName;
  final String lastMessage;
  final String lastMessageAt;
  final int unreadCount;

  const ConversationModel({
    required this.id,
    required this.participantName,
    required this.lastMessage,
    required this.lastMessageAt,
    required this.unreadCount,
  });

  factory ConversationModel.fromJson(Map<String, dynamic> json) {
    return ConversationModel(
        id: json['id'],
        participantName: json['participantName'],
        lastMessage: json['lastMessage'],
        lastMessageAt: json['lastMessageAt'],
        unreadCount: json['unreadCount'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
        'id': id,
        'participantName': participantName,
        'lastMessage': lastMessage,
        'lastMessageAt': lastMessageAt,
        'unreadCount': unreadCount,
    };
  }
}
