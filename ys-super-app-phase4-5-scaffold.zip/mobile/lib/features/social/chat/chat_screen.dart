import 'package:flutter/material.dart';

/// المحادثات
/// الوظيفة: واجهة قائمة المحادثات الخاصة
/// TODO: ربط الشاشة بـ ChatService لعرض المحادثات الفعلية
class SocialChatScreen extends StatefulWidget {
  const SocialChatScreen({super.key});

  @override
  State<SocialChatScreen> createState() => _SocialChatScreenState();
}

class _SocialChatScreenState extends State<SocialChatScreen> {
  bool _isLoading = false;
  String? _errorMessage;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المحادثات')),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_errorMessage!, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => setState(() => _errorMessage = null),
              child: const Text('إعادة المحاولة'),
            ),
          ],
        ),
      );
    }
    // TODO: ربط الشاشة بـ ChatService لعرض المحادثات الفعلية
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'هذه الشاشة قيد التطوير وسيتم ربطها بالخدمة الفعلية في مرحلة لاحقة.',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
