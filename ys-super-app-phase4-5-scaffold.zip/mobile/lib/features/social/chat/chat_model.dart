/// نموذج بيانات المحادثة الواحدة

class ChatModel {
  final String id;
  final bool isGroup;
  final String title;
  final String createdAt;

  const ChatModel({
    required this.id,
    required this.isGroup,
    required this.title,
    required this.createdAt,
  });

  factory ChatModel.fromJson(Map<String, dynamic> json) {
    return ChatModel(
        id: json['id'],
        isGroup: json['isGroup'],
        title: json['title'],
        createdAt: json['createdAt'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
        'id': id,
        'isGroup': isGroup,
        'title': title,
        'createdAt': createdAt,
    };
  }
}
