/// نموذج بيانات رسالة المساعد الذكي — يمثل رسالة المستخدم أو رسالة الذكاء الاصطناعي

class AssistantMessage {
  final String id;
  final String text;
  final bool isFromUser;
  final String timestamp;
  final String type;

  const AssistantMessage({
    required this.id,
    required this.text,
    required this.isFromUser,
    required this.timestamp,
    required this.type,
  });

  factory AssistantMessage.fromJson(Map<String, dynamic> json) {
    return AssistantMessage(
        id: json['id'],
        text: json['text'],
        isFromUser: json['isFromUser'],
        timestamp: json['timestamp'],
        type: json['type'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
        'id': id,
        'text': text,
        'isFromUser': isFromUser,
        'timestamp': timestamp,
        'type': type,
    };
  }
}
