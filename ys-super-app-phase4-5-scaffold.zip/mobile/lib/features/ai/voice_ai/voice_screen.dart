import 'package:flutter/material.dart';

/// الأوامر الصوتية
/// الوظيفة: واجهة تفعيل الميكروفون وعرض حالة الاستماع والنص الناتج
/// TODO: ربط الشاشة بـ VoiceService لتشغيل الميكروفون وتحويل الصوت إلى نص
class VoiceScreen extends StatefulWidget {
  const VoiceScreen({super.key});

  @override
  State<VoiceScreen> createState() => _VoiceScreenState();
}

class _VoiceScreenState extends State<VoiceScreen> {
  bool _isLoading = false;
  String? _errorMessage;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الأوامر الصوتية')),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_errorMessage!, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => setState(() => _errorMessage = null),
              child: const Text('إعادة المحاولة'),
            ),
          ],
        ),
      );
    }
    // TODO: ربط الشاشة بـ VoiceService لتشغيل الميكروفون وتحويل الصوت إلى نص
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'هذه الشاشة قيد التطوير وسيتم ربطها بالخدمة الفعلية في مرحلة لاحقة.',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
