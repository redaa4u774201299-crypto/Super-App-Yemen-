-- جدول الاقتراحات الذكية المولدة للمستخدمين
-- ملاحظة: هذا الجدول جزء من هيكل قاعدة البيانات الأولي (Skeleton).
-- يجب مراجعته وتخصيصه (المفاتيح الخارجية، الفهارس، القيود) عند الربط الفعلي.

CREATE TABLE IF NOT EXISTS recommendations (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL,
    category VARCHAR(30) NOT NULL,
    reference_id BIGINT,
    score DECIMAL(5,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_recommendations_user ON recommendations (user_id, category);
