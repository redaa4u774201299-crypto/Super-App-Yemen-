-- جدول إعدادات الذكاء الاصطناعي لكل مستخدم
-- ملاحظة: هذا الجدول جزء من هيكل قاعدة البيانات الأولي (Skeleton).
-- يجب مراجعته وتخصيصه (المفاتيح الخارجية، الفهارس، القيود) عند الربط الفعلي.

CREATE TABLE IF NOT EXISTS ai_settings (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL UNIQUE,
    assistant_enabled BOOLEAN DEFAULT TRUE,
    voice_enabled BOOLEAN DEFAULT TRUE,
    auto_translate BOOLEAN DEFAULT FALSE,
    preferred_language VARCHAR(10) DEFAULT 'ar',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
