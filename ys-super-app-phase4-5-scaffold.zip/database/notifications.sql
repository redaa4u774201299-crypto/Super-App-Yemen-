-- جدول الإشعارات الاجتماعية
-- ملاحظة: هذا الجدول جزء من هيكل قاعدة البيانات الأولي (Skeleton).
-- يجب مراجعته وتخصيصه (المفاتيح الخارجية، الفهارس، القيود) عند الربط الفعلي.

CREATE TABLE IF NOT EXISTS notifications (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL,
    type VARCHAR(30) NOT NULL,
    message VARCHAR(255) NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_notifications_user ON notifications (user_id);
