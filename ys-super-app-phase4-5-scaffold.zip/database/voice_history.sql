-- جدول سجل الأوامر الصوتية
-- ملاحظة: هذا الجدول جزء من هيكل قاعدة البيانات الأولي (Skeleton).
-- يجب مراجعته وتخصيصه (المفاتيح الخارجية، الفهارس، القيود) عند الربط الفعلي.

CREATE TABLE IF NOT EXISTS voice_history (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL,
    audio_path VARCHAR(255),
    transcript TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_voice_history_user ON voice_history (user_id);
