-- جدول المستخدمين الأساسي
-- ملاحظة: هذا الجدول جزء من هيكل قاعدة البيانات الأولي (Skeleton).
-- يجب مراجعته وتخصيصه (المفاتيح الخارجية، الفهارس، القيود) عند الربط الفعلي.

CREATE TABLE IF NOT EXISTS users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100) NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    phone VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(120),
    city VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
